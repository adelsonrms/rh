﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERP.Presentation.Api.Authentication.Apps
{
    //App ID : ac6aad15-111e-4f79-a816-64c85dba0736
    //Chave : pzmLMTIM8_%hjiyXH6615^_
    public class Office365Login
    {
    }
}