﻿using ERP.Shared.Web;
using Microsoft.AspNet.Identity;
using MSGraph.Services;
using MSGraphService.RestServices.Auth;
using MSGraphService.RestServices.Clients;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Message = MSGraphService.Models.Message;
using ProfilePhoto = MSGraphService.Models.ProfilePhoto;
using User = MSGraphService.Models.User;

namespace ERP.Presentation.Api.Controllers
{
    public class AuthController : Controller
    {
        // GET: Auth
        [HttpPost]
        [Authorize]
        public async Task<JsonResult> GetUserInfo()
        {
            var MSGraph = new MSGraphApiService(new AppClient());

            //Recupera informações sobre o perfil do usuario atraves do email
            Response responseQuery = await MSGraph.GetUser<User>(HttpContext.User.Identity.GetUserName());
            var user = responseQuery.Data;

            if (user.IsValid())
            {
                return Json(user);
            }
            else
            {
                return Json(new User(){GivenName = "Erro"});
            }
            
        }

        public async Task<JsonResult> GetUserMessages()
        {
            var MSGraph = new MSGraphApiService(new AppClient());

            try
            {
                //Recupera informações sobre o perfil do usuario atraves do email
                //Nessa consulta, somente as 5 primeiras mensagens ordenadas por chegada serão recuperadas.

                //Parametro de filtro OData

                var filtroOData = "?&$top=5&$orderby=receivedDateTime desc&$filter=isRead eq false";
                /*
                 *  top=5                               : Somente os ultimos 5 emails
                 *  orderby=receivedDateTime desc       : Ordena o resultado pela data de recebimento Decrescente
                 *  filter=isRead eq false              : Filtra somente os itens não lidos
                 *  O end-point abaixo recupera somente as mensagens da caixa de entrada
                 *  https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages?$filter=isRead eq false
                 */

                Response responseQuery = await MSGraph.GetMessages<Message>(HttpContext.User.Identity.GetUserName(), filtroOData);
                var messages = responseQuery.Data;

                //Obtem a leitura dos objetos Message
                var conteudo = ((JContainer)messages).Last;

                var items = conteudo.Children();

                List<Message> list = new List<Message>();

                foreach (var item in items)
                {
                    //Serializa o JSon retornado para o objeto
                    item.Children().ToList().ForEach(m => list.Add(m.ToObject<Message>()));
                }

                return Json(list, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                return Json(new {Error = ex.Message}, JsonRequestBehavior.AllowGet);
            }

        }


        public async Task<JsonResult> GetPhoto(string tamanho)
        {
            string photoBase64 = Imagens.UserDesconhecido;

            try
            {
                photoBase64 = await GetUserPhoto(HttpContext.User.Identity.GetUserName(), tamanho);
            }
            catch 
            {

            }
            return Json(new { imageBase64 = photoBase64 });
        }

        public async Task<JsonResult> GetPhoto360()
        {
            string photoBase64 = Imagens.UserDesconhecido;

            try
            {
                photoBase64 = await GetUserPhoto(HttpContext.User.Identity.GetUserName(), "120x120");
            }
            catch
            {

            }
            return Json(new { imageBase64 = photoBase64 });
        }

        public async Task<string> GetUserPhoto(string userId, string tamanho)
        {
            var MSGraph = new MSGraphApiService(new AppClient());
            string mediaType="";
            string thumbnail="";

            //Recupera informações sobre o perfil do usuario atraves do email
            Response responseQuery = await MSGraph.GetPhoto<ProfilePhoto>(userId, tamanho);

            var response = responseQuery.HttpResponse;

            if (response.IsSuccessStatusCode)
            {
                // Read the response as a byte array
                var responseBody = response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult();

                // The headers will contain information on the image type returned
                mediaType = response.Content.Headers.ContentType.MediaType;

                // Encode the image string
                thumbnail = Convert.ToBase64String(responseBody);
            }

            return $"data:{mediaType};base64,{thumbnail}";
        }

        public ActionResult SignOut()
        {
            Request.GetOwinContext().Authentication.SignOut("Cookies");
            return RedirectToAction("Index", "Home");
        }

    }
}